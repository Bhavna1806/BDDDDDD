package stepdefinitions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import ElementLocators.ElementLocators;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;

public class StepDefinitions {
	WebDriver driver=null;
	@Given("^User is on Login page$")
	public void user_is_on_Login_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String url="file:///C:/Users/asing454/Desktop/BDD_Workspace/Hotel%20booking%20case%20study/login.html";
		pagefactory.PageFactory.openbrowser(url);
	}
	@When("^User verify title$")
	public void user_verify_title() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		pagefactory.PageFactory.verifytitle(ElementLocators.HeadingName);
		System.out.println("equal");
	}
	@When("^User enter UserName$")
	public void user_enter_UserName() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		pagefactory.PageFactory.sendValue(ElementLocators.UserName, "capgemini");
	}

	@When("^User enter Password\\.$")
	public void user_enter_Password() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		pagefactory.PageFactory.sendValue(ElementLocators.Password, "capg1234");
	}

	@When("^User click login button$")
	public void user_click_login_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		pagefactory.PageFactory.clickmethod(ElementLocators.Login);
	}

	@Then("^User is login successfully$")
	public void user_is_login_successfully() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("Login Successfull");
	}

	@Given("^User is on Booking Page$")
	public void user_is_on_Booking_Page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("Booking page opened");
	}

	@When("^User verify heading$")
	public void user_verify_heading() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		pagefactory.PageFactory.verifyheading(ElementLocators.Title);
		System.out.println("equal");
	}

	@When("^User Enter First Name$")
	public void user_Enter_First_Name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		pagefactory.PageFactory.sendValue(ElementLocators.firstname, "ankit");
	}

	@When("^User enter last name$")
	public void user_enter_last_name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		pagefactory.PageFactory.sendValue(ElementLocators.lastname, "singh");
	}

	@When("^User Enter Email$")
	public void user_Enter_Email() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		pagefactory.PageFactory.sendValue(ElementLocators.email, "ankitsingh@gmail.com");
	}

	@When("^User Enter mobile no$")
	public void user_Enter_mobile_no() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		pagefactory.PageFactory.sendValue(ElementLocators.phone, "9557777777");
	}

	@When("^User Select Number of people staying at the Hotel$")
	public void user_Select_Number_of_people_staying_at_the_Hotel() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		pagefactory.PageFactory.select(ElementLocators.numberofpersons, "1");
	}

	@When("^User Enter address details$")
	public void user_Enter_address_details() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		pagefactory.PageFactory.sendValue(ElementLocators.address, "Sipcot IT Park");
	}

	@When("^User Select City$")
	public void user_Select_City() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		pagefactory.PageFactory.select(ElementLocators.city, "Pune");
	}

	@When("^User Select State$")
	public void user_Select_State() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		pagefactory.PageFactory.select(ElementLocators.state, "Karnataka");
	}

	@When("^User Enter Card Holder Name$")
	public void user_Enter_Card_Holder_Name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		pagefactory.PageFactory.sendValue(ElementLocators.holdername, "ankit singh");
		
		
	}

	@When("^User Enter Debit card Number$")
	public void user_Enter_Debit_card_Number() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		pagefactory.PageFactory.sendValue(ElementLocators.cardnumber, "952354454854");
		pagefactory.PageFactory.sendValue(ElementLocators.cvv, "550");
	}

	@When("^User Card expiration month$")
	public void user_Card_expiration_month() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		pagefactory.PageFactory.sendValue(ElementLocators.month, "08");
	}

	@When("^User Enter Card expiration year$")
	public void user_Enter_Card_expiration_year() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		pagefactory.PageFactory.sendValue(ElementLocators.year, "2025");
	}

	@When("^User Click on Confirm Booking button$")
	public void user_Click_on_Confirm_Booking_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		pagefactory.PageFactory.clickmethod(ElementLocators.confirm);
	}

	@Then("^Booking is done$")
	public void booking_is_done() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Thread.sleep(3000);
		pagefactory.PageFactory.close();
	}
	}

