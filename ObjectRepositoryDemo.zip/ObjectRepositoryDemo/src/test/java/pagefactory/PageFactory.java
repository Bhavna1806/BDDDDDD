package pagefactory;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import ElementLocators.ElementLocators;
import junit.framework.Assert;

public class PageFactory {
	static WebDriver driver;
	public static void openbrowser(String url)
	{
		System.setProperty("webdriver.chrome.driver", "./driver/chromedriver.exe");
		driver=new ChromeDriver();
		driver.navigate().to(url);
		System.out.println("Browser updated");
		driver.manage().window().maximize();
	}
	public static void sendValue(By locator, String val)
	{
		//WebElement ele=driver.findElement(locator);
		WebElement ele=driver.findElement(locator);
		System.out.println("The text "+val +"is entered");
		ele.sendKeys(val);
	}
	public static void clickmethod(By locatorforClick) throws InterruptedException
	{
		driver.findElement(locatorforClick).click();
		System.out.println(locatorforClick+ "is clicked");
	Thread.sleep(3000);
	}
	public static void close() {
	System.out.println("Closing the window");
		driver.close();
	}
	public static void select(By locator,String val) {
		WebElement ad=driver.findElement(locator);
		Select dd=new Select(ad);
		dd.selectByVisibleText(val);
	System.out.println("The value : " +val+ "is selected");
	}
 public static void verifytitle(By locator) {
	 String sText=driver.findElement(locator).getText();
	 Assert.assertEquals("Hotel Booking Application", sText);
	 
 }
public static void verifyheading(By title) {
	// TODO Auto-generated method stub
	 String sText=driver.findElement(title).getText();
	 Assert.assertEquals("Hotel Booking Form", sText);
}
public static void alertHandler() {
	driver.switchTo().alert().accept();
}
}
