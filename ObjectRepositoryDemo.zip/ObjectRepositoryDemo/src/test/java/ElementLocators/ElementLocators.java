package ElementLocators;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;

public class ElementLocators {
	public static By HeadingName=By.xpath("//h1[text()=' Hotel Booking Application ']");
	public static By UserName=By.name("userName");
	public static By Login=By.className("btn");
	public static By Password=By.name("userPwd");
	
	public static By Title=By.xpath("//h2[text()='Hotel Booking Form']");
	public static By firstname=By.className("Format1");
	public static By address=By.xpath("//textarea");
	public static By lastname=By.id("txtLastName");
	public static By email=By.id("txtEmail");
	public static By phone=By.id("txtPhone");
	public static By city=By.name("city");
	public static By state=By.name("state");
	public static By numberofpersons=By.name("persons");
	public static By holdername=By.id("txtCardholderName");
	public static By cardnumber=By.id("txtDebit");
	public static By cvv=By.name("cvv");
	public static By month=By.name("month");
	public static By year=By.name("year");
	public static By confirm=By.id("btnPayment");

}
