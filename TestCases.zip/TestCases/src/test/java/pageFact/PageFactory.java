package pageFact;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import junit.framework.Assert;
public class PageFactory {
	static WebDriver driver;

	public static void openbrowser()
	{
		System.setProperty("webdriver.chrome.driver","./driver/chromedriver.exe");
		driver= new ChromeDriver();
		
		System.out.println("Browser opened");
		driver.manage().window().maximize();		
	}
	public static void linkOpenLogin(String url,By locator)
	{
		driver.get(url);
		WebElement w1=driver.findElement(locator);
		Assert.assertEquals("Registration Form App", w1.getText());	
	}
	public static void insertKeys(String val,By locator) {
		driver.findElement(locator).sendKeys(val);
	}
	
	public static void clickMethod(By locator) {
		driver.findElement(locator).click();
	}
	
	public static void verifyTitle() {
		String title = driver.getTitle();
		Assert.assertEquals("RegistrationForm",title);
	}
	public static void alertHandler() {
		driver.switchTo().alert().accept();
	}
	public static void clearBox(By locator) {
		driver.findElement(locator).clear();
	}
	public static void select(By locator) {
		WebElement element= driver.findElement(locator);
		Select select=new Select(element);
		select.selectByIndex(2);
	}
}
