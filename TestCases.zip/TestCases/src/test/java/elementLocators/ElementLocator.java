package elementLocators;

import org.openqa.selenium.By;

public class ElementLocator {

	public static By registration = By.xpath("//h1[text()=' Registration Form ']");
	public static By userid = By.xpath("//input[@name='userId']");
	public static By password = By.xpath("//input[@name='passid']");
	public static By username = By.xpath("//input[@value='username']");
	public static By address = By.xpath("//input[@name='address']");

	public static By country = By.xpath("//input[@name='country']");
	public static By zipcode = By.xpath("//input[@name='zip']");

	public static By Email = By.xpath("//input[@name='Email']");

	public static By sex = By.xpath("//input[@name='sex']");
	public static By language = By.xpath("//input[@name='en']");

	public static By about = By.xpath("//input[@name='desc']");
	public static By loginlink = By.id("btnPayment");
	/*
	 * public static By loginlink=By.xpath("//input[@value='Login']"); public static
	 * By userName=By.xpath("//input[@name='userName']"); public static By
	 * password=By.xpath("//input[@name='userPwd']"); public static By
	 * loginTitle=By.xpath("//h1[text()=' Hotel Booking Application ']"); public
	 * static By firstName=By.id("txtFirstName"); public static By
	 * bookButton=By.id("btnPayment"); public static By
	 * lastName=By.id("txtLastName"); public static By email=By.id("txtEmail");
	 * public static By mobile=By.id("txtPhone"); public static By
	 * address=By.xpath("//textarea"); public static By
	 * city=By.xpath("//select[@name='city']"); public static By
	 * state=By.xpath("//select[@name='state']"); public static By
	 * persons=By.xpath("//select[@name='persons']"); public static By
	 * cardHolderName=By.id("txtCardholderName"); public static By
	 * cardNumber=By.id("txtDebit"); public static By cvv=By.id("txtCvv"); public
	 * static By expiryMon=By.id("txtMonth"); public static By
	 * expiryYear=By.id("txtYear");
	 */
	
	
}
