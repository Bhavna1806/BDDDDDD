package stepDefinitions;

import org.openqa.selenium.support.PageFactory;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import elementLocators.ElementLocator;

public class StepDefinition {
	@Given("^Login Page$")
	public void login_Page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		pageFact.PageFactory.openbrowser();
		
	}

	@When("^User come to login page$")
	public void user_come_to_login_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		pageFact.PageFactory.linkOpenLogin("C://Users//bhawnsha//Desktop//M4444//M4 set2 webpages//WebPages/RegistrationForm.html",ElementLocator.registration);
		
	}

	@When("^Input username$")
	public void input_username() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		
		Thread.sleep(2000);
		
		//pagefact.Methods.SendValue("bhawna", locators.Locators.username);
		pageFact.PageFactory.insertKeys("capgemini",ElementLocator.username);
		
		
	}

	@When("^Input password$")
	public void input_password() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		pageFact.PageFactory.clickMethod(ElementLocator.loginlink);
		Thread.sleep(2000);
		pageFact.PageFactory.insertKeys("capg1234",ElementLocator.password);
	}

	@Then("^Click on Login button$")
	public void click_on_Login_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		pageFact.PageFactory.clickMethod(ElementLocator.loginlink);
	}
	
	//registration form
	@Given("^registration form$")
	public void registration_form() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		pageFact.PageFactory.verifyTitle();
	}

	@When("^user validate userId$")
	public void user_validate_Name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		
		pageFact.PageFactory.alertHandler();
		Thread.sleep(2000);
		pageFact.PageFactory.insertKeys("Bhavna",ElementLocator.username);
		pageFact.PageFactory.clickMethod(ElementLocator.loginlink);
		
	}

	

	@When("^user validate Email$")
	public void user_validate_Email() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		pageFact.PageFactory.insertKeys("bhavnasharma",ElementLocator.Email);
		pageFact.PageFactory.clickMethod(ElementLocator.loginlink);
		pageFact.PageFactory.alertHandler();
		Thread.sleep(2000);
		pageFact.PageFactory.clearBox(ElementLocator.Email);
		pageFact.PageFactory.insertKeys("bhavnasharma@gmail.com",ElementLocator.Email);
	}

	

	@When("^user validate Address$")
	public void user_validate_Address() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		pageFact.PageFactory.insertKeys("Capgemini, Sipcot, Siruseri, Chennai",ElementLocator.address);
	}

	@When("^user select country$")
	public void user_select_country() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		pageFact.PageFactory.clickMethod(ElementLocator.loginlink);
		pageFact.PageFactory.alertHandler();
		Thread.sleep(2000);
		pageFact.PageFactory.select(ElementLocator.country);
	}

	@When("^user select zipcode$")
	public void user_select_zipcode() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		pageFact.PageFactory.clickMethod(ElementLocator.loginlink);
		pageFact.PageFactory.alertHandler();
		Thread.sleep(2000);
		pageFact.PageFactory.select(ElementLocator.zipcode);
	}

	
	@Then("^click on confirm registration$")
	public void click_on_confirm_booking() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Thread.sleep(2000);
		pageFact.PageFactory.clickMethod(ElementLocator.loginlink);
	}
	
	@When("^user select sex$")
	public void user_select_sex() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		pageFact.PageFactory.clickMethod(ElementLocator.loginlink);
		pageFact.PageFactory.alertHandler();
		Thread.sleep(2000);
		pageFact.PageFactory.select(ElementLocator.sex);
	}
	
	@When("^user select language$")
	public void user_select_language() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		pageFact.PageFactory.clickMethod(ElementLocator.loginlink);
		pageFact.PageFactory.alertHandler();
		Thread.sleep(2000);
		pageFact.PageFactory.select(ElementLocator.language);
	}
}
