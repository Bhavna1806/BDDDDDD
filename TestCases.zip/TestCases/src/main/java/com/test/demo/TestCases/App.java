package com.test.demo.TestCases;

import org.apache.xpath.operations.String;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
    }
}
